# coding: utf-8
from app_version import get_versions
__version__, VERSION = get_versions('notify', allow_ambiguous=True)
